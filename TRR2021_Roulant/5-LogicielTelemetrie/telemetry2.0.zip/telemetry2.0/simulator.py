#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Simulator main entry for telemetry2.0, main features are :
- read and send data to serial interface

Mandaroy:
pip3 install pyserial

Usefull:
for mac user : socat -d -d pty,raw,echo=0 pty,raw,echo=0
"""

#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# Import
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
import sys
from argparse import ArgumentParser
from lib import banner
from lib import msgType
import serial
import io
import time
from datetime import datetime
from random   import randrange

#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# Main function
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
def main():
  nbMsgSent = 0
    
  # Display context
  print(banner.Banner("Simulator").show())
  
  # Check parameters
  parser = ArgumentParser()
  parser.add_argument("-s", "--sport", dest="serial_port", required=True,
                      help="port com for serial connection", type=str)
  parser.add_argument("-e", "--speed", dest="serial_speed",
                      help="serial speed for serial connection", type=int, default=115200)
  args = parser.parse_args()

  # Open serial connection
  try:
    ser = serial.Serial(port=args.serial_port, baudrate=args.serial_speed, timeout = 0)
    sio = io.TextIOWrapper(io.BufferedRWPair(ser, ser))
  except Exception as e:
    print (f"#> Unable to open serial port {args.serial_port} with speed {args.serial_speed}")
    print(e)
    return(1)
  print(f" > Connected to serial port {args.serial_port} with speed {args.serial_speed}")

  # Start/Stop telemetry
  sendTelemetry = False

  # Infinite loop, till the end
  goOn = 1
  while goOn:

    # Breath, read command & Check exit signal ?
    try:
      time.sleep(.01)
      rx_buffer = sio.readline()
    except KeyboardInterrupt:
      goOn = 0
      print(" > Exit by user (CTRL+C)")

    # manage received command
    if len(rx_buffer) != 0:
      print(" > command receive: %s", rx_buffer)

      # START_TELEMETRY
      if (rx_buffer == str(msgType.Id.start_telemetry_serial)):
        sendTelemetry = True

      # STOP_TELEMETRY
      if (rx_buffer == str(msgType.Id.stop_telemetry_serial)):
          sendTelemetry = False
      
      # REQ_GET_PARAM
      if (rx_buffer == str(msgType.Id.get_param_serial)):
        txt = 'p;1.898;099;GNV'
        print('%s# Send serial response: %s' % (datetime.now().strftime('%M:%S.%f'), txt))
        sio.flush()
        sio.write(txt)
        sio.flush()
        time.sleep(0.05)

    # Build and publish string
    if sendTelemetry == True:
      nbMsgSent += 1
      value1 = randrange(0, 70)
      value2 = randrange(0, 100)
      value3 = 1.387 * randrange(-100, 300)
      txt = 't;%i;%i;%f' % (value1, value2, value3)
      #print('%s# Send serial telemetry (%d): %s' % (datetime.now().strftime('%M:%S.%f'), \
      #                                              nbMsgSent, \
      #                                              txt))

      sio.write(txt)
      sio.flush()
          
    # End of while

  return(0)

#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# Here we are...
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
if __name__ == '__main__':
  sys.exit(main())

# Eof
